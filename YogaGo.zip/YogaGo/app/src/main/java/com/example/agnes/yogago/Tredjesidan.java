package com.example.agnes.yogago;

import android.app.ListActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

public class Tredjesidan extends ListActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tredjesidan);
        String[] ställen = {"Jinyoga", "Anusarayoga", "Ashtangayoga"}; //Skapar en string array med mina olika yogatyper
        ArrayAdapter adapter = new ArrayAdapter<String>(getListView().getContext(), android.R.layout.simple_dropdown_item_1line, ställen);
        getListView().setAdapter(adapter);
    }
}
