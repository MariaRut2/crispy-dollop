package com.example.agnes.yogago;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Inloggad extends AppCompatActivity {

    public  Button knapp2; // skapar jag inte en ny knapp här kommer inte  min metod förstå vilken som är knapp 2
    public void setKnapp2(){ //här skapar jag min metod som ska göra att jag kommer till min sista sida
        knapp2 = (Button) findViewById(R.id.knapp2);
        knapp2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent kommaTillSistaSidan = new Intent(Inloggad.this,Tredjesidan.class); // intent är en funktion där du vill tala om för progamet vad duvill ska hända därför behöver jag en intent variabl här med
                startActivity(kommaTillSistaSidan);// för att programmet ska vara körbart behöver du alltså lägga till din varabel(intent kommavidare) i start aktivity samma som på mainsidan
            }
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inloggad);
        setKnapp2(); //även här behöver jag anropa min metod
    }
}
