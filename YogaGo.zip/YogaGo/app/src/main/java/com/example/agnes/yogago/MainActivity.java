package com.example.agnes.yogago;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;



public class MainActivity extends AppCompatActivity {

    public Button knapp;

    public void setKnapp(){ //här skapar jag min metod som ska göra att jag kommer till inloggad sidan
       knapp= (Button) findViewById(R.id.knapp);
       knapp.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent kommaVidare = new Intent(MainActivity.this,Inloggad.class); // intent är en funktion där du vill tala om för progamet vad duvill ska hända
               startActivity(kommaVidare);// för att programmet ska vara körbart behöver du alltså lägga till din varabel(intent kommavidare) i start aktivity
           }
       });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setKnapp(); // för att min metod ska anropas behöver jag ange det här. Detta är den kod som körs när jag startar mitt program
    }


}
